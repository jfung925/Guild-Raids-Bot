'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { buildLeaderboard } = require('../../helpers/leaderboard.helper');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('guildraids')
    .setDescription('Show the Wynncraft guild raid leaderboard.')
    .addIntegerOption(option => option.setName('page')
      .setDescription('Page number: 25 members per page.').setMinValue(1))
    .addStringOption(option => option.setName('scope')
      .setDescription('Choose which cumulative raid counter to show.')
      .addChoices(
        { name: 'Raids in this guild', value: 'current' },
        { name: 'Guild raids across all guilds', value: 'all' },
      )),

  async execute(interaction, { api }) {
    // Acknowledge before the API request so Discord does not time out the command.
    await interaction.deferReply();
    const snapshot = await api.getGuild();
    const embed = buildLeaderboard(snapshot, {
      page: interaction.options.getInteger('page') ?? 1,
      scope: interaction.options.getString('scope') ?? 'current',
    });
    await interaction.editReply({ content: null, embeds: [embed], allowedMentions: { parse: [] } });
  },
};
