'use strict';

const { MessageFlags, SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder().setName('help').setDescription('Explain the raid leaderboard commands.'),
  async execute(interaction) {
    await interaction.reply({
      content: '**/guildraids** — cumulative raids in this guild, 25 members per page.\n'
        + '**/guildraids page:2** — the next page, when available.\n'
        + '**/guildraids scope:all** — current members\' guild raids across all guilds.\n'
        + '**/ping** — check the bot connection.\n\n'
        + 'The roster is loaded automatically. Unavailable means a count is missing or restricted. '
        + 'These counters are not weekly totals. API caching can delay recent changes.',
      flags: MessageFlags.Ephemeral,
      allowedMentions: { parse: [] },
    });
  },
};
