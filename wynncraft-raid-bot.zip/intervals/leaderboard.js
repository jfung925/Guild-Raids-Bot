'use strict';

/** Update a single persistent message; schedule only after each update finishes. */
const { ChannelType } = require('discord.js');
const { buildLeaderboard } = require('../helpers/leaderboard.helper');

class LeaderboardTask {
  constructor({ client, settings, api, store, log, messageId = null }) {
    Object.assign(this, { client, settings, api, store, log, messageId });
    this.running = false;
    this.timer = null;
    this.inFlight = null;
  }

  async refresh() {
    // Also guard direct refresh calls, so two callers cannot post two first boards.
    if (this.inFlight) return this.inFlight;
    this.inFlight = this.update();
    try {
      return await this.inFlight;
    } finally {
      this.inFlight = null;
    }
  }

  async update() {
    const channel = await this.client.channels.fetch(this.settings.channelId);
    if (!channel || channel.type !== ChannelType.GuildText || channel.guildId !== this.settings.serverId) {
      throw new Error('LEADERBOARD_CHANNEL_ID must identify a regular text channel in DISCORD_SERVER_ID.');
    }
    // Fetch first. If Wynncraft fails, leave the old message and its timestamp intact.
    const snapshot = await this.api.getGuild();
    const payload = { embeds: [buildLeaderboard(snapshot, { automatic: true })],
      allowedMentions: { parse: [] } };
    let message = null;
    if (this.messageId) {
      try {
        message = await channel.messages.fetch({ message: this.messageId, cache: false, force: true });
      } catch (error) {
        // Only Unknown Message means it was deleted. Permission/network errors
        // must not cause a replacement message on every interval.
        if (Number(error.code) !== 10008) throw error;
        this.messageId = null;
      }
    }
    if (message) {
      if (message.author.id !== this.client.user.id) throw new Error('Saved board belongs to another user. Check leaderboard.json.');
      await message.edit(payload);
    } else {
      message = await channel.send(payload);
      // Keep this ID in memory even if saving to disk fails, allowing a later retry.
      this.messageId = message.id;
    }
    await this.store.save(this.settings.serverId, this.settings.channelId, this.messageId);
    this.log.info('Leaderboard refreshed; ' + snapshot.members.length + ' members returned.');
  }

  start() {
    if (this.running) return;
    this.running = true;
    void this.tick();
  }

  async tick() {
    try {
      await this.refresh();
    } catch (error) {
      this.log.warn('Automatic leaderboard update failed; will retry next interval.', error);
    } finally {
      if (this.running) {
        this.timer = setTimeout(() => { void this.tick(); }, this.settings.refreshSeconds * 1000);
      }
    }
  }

  async stop() {
    this.running = false;
    clearTimeout(this.timer);
    // Finish an active save before disconnecting when the host sends SIGTERM.
    if (this.inFlight) await this.inFlight.catch(() => {});
  }
}

module.exports = { LeaderboardTask };
